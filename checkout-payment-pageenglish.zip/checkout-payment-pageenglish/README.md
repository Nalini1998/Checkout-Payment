# Checkout (Payment) Page - English

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/VwVgXRM/6c41edcfdea61dae38d11ca9db5fdab5](https://codepen.io/Nalini1998/pen/VwVgXRM/6c41edcfdea61dae38d11ca9db5fdab5).

# Checkout Page

This project is a checkout page created by Meow.Nalini98. The checkout page is a web user interface that allows website users to purchase a product or service by submitting a payment form online. This mock checkout page is designed to be responsive and viewable on any device.

## Getting Started

Clone or download the code to your local machine. Open the `index.html` file in a web browser to view the page.

### Prerequisites

No prerequisites are needed for this project.

### Built With

This project was built using the following technologies:

* [HTML](https://www.w3.org/html/)
* [CSS](https://www.w3.org/Style/CSS/Overview.en.html)

### Author

* **Nalini Vo** - Initial work - [Nalini1998](https://github.com/Nalini1998)

### Acknowledgments

* [W3Schools](https://www.w3schools.com/) - Used as a reference for the layout and styling of the page.
* [Font Awesome](https://fontawesome.com/) - Used to display icons. 
* [Google Fonts](https://fonts.google.com/) - Used to import the Roboto font.